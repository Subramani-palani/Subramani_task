import { Routes } from '@angular/router';

import { LoginFormComponent } from './login-form/login-form.component';
import { ContactComponent } from './contact/contact.component';



export const routes: Routes = [
    
    {
        path:"Edit Form",
        component: LoginFormComponent
    },
    {
        path:"Contact",
        component: ContactComponent
    }
    
];
